/**
 * 
 */
package com.learning.slate.toolkits;

/**
 * @author cbryant
 *
 */
public interface ISlateObject {
	public int getSymbolID();
	public float getX();
	public float getY();
	public float getAngle();
}
