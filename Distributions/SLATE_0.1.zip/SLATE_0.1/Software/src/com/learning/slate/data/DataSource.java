/**
 * 
 */
package com.learning.slate.data;

/**
 * @author cbryant
 *
 */
public enum DataSource
{
	Live,
	Log,
	Network
}
